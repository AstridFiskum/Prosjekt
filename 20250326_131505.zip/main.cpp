#include "std_lib_facilities.h"
#include "cannonball.h"

int main()
{
	return 0;
}